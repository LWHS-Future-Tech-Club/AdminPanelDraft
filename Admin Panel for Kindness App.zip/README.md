
  # Admin Panel for Kindness App

  This is a code bundle for Admin Panel for Kindness App. The original project is available at https://www.figma.com/design/aNE2pypHgNuMQ9PFiheunQ/Admin-Panel-for-Kindness-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  